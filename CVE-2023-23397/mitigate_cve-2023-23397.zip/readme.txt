HIGH SEVERITY MS OFFICE VULNERABILITY MITIGATION
This script helps mitigate Microsoft Outlook CVE-2023-23397 vulnerability.
As at 16-03-2023 MS patches are available see article below.

This script is a temporary workaround if you are unable to apply the patches at this stage.
It follows Microsoft recommendation to temporarily enable Windows Firewall and block outbound port 445/SMB 
This may impact file collaboration on local Sharepoint files or other software packages

https://msrc.microsoft.com/update-guide/vulnerability/CVE-2023-23397 

From Windows 10/11 copy the batch file and powershell script to a temporary folder then run apply_patch.bat

Script will prompt for administrator access or credentials as it enables and updates the Windows firewall rules.
